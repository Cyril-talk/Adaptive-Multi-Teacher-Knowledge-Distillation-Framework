#!/usr/bin/env python3
"""
完全独立的t-SNE可视化脚本
通过调用方式为多教师知识蒸馏模型生成特征分布可视化图
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.manifold import TSNE
from sklearn.decomposition import PCA
from PIL import Image
import torchvision.transforms as transforms
import json
import argparse
from pathlib import Path
import os
from typing import Dict, List, Tuple, Optional
import warnings

warnings.filterwarnings('ignore')

# 设置matplotlib中文显示
plt.rcParams['font.sans-serif'] = ['SimHei', 'DejaVu Sans', 'Arial']
plt.rcParams['axes.unicode_minus'] = False


class FeatureExtractor:
    """特征提取器 - 从预训练模型中提取特征"""

    def __init__(self, model, device, hook_layers=None):
        self.model = model
        self.device = device
        self.features = {}
        self.hooks = []
        self.hook_layers = hook_layers or ['final']

        # 注册钩子函数
        if 'final' not in self.hook_layers:
            self._register_hooks()

    def _register_hooks(self):
        """注册前向钩子来提取中间层特征"""

        def hook_fn(name):
            def hook(module, input, output):
                if isinstance(output, torch.Tensor):
                    self.features[name] = output.detach()
                elif isinstance(output, (list, tuple)) and len(output) > 0:
                    self.features[name] = output[0].detach()

            return hook

        # 根据常见的层名注册钩子
        for name, module in self.model.named_modules():
            if any(layer_name in name.lower() for layer_name in ['conv', 'block', 'layer']):
                if name in self.hook_layers:
                    handle = module.register_forward_hook(hook_fn(name))
                    self.hooks.append(handle)

    def extract_features_from_data(self, dataloader, max_samples=800):
        """从数据加载器中提取特征"""
        self.model.eval()
        all_features = []
        all_labels = []
        sample_count = 0

        with torch.no_grad():
            for batch_data in dataloader:
                if sample_count >= max_samples:
                    break

                # 解析batch数据
                if isinstance(batch_data, (list, tuple)) and len(batch_data) >= 2:
                    images, targets = batch_data[0], batch_data[1]
                elif isinstance(batch_data, dict):
                    images = batch_data.get('image', batch_data.get('images'))
                    targets = batch_data.get('label', batch_data.get('labels'))
                else:
                    print(f"Unexpected batch format: {type(batch_data)}")
                    continue

                if images is None:
                    continue

                images = images.to(self.device)

                # 前向传播
                try:
                    if hasattr(self.model, '__call__'):
                        if len(images.shape) == 4:  # [B, C, H, W]
                            outputs = self.model(images)
                        else:
                            continue
                    else:
                        continue

                    # 提取最终特征
                    if isinstance(outputs, torch.Tensor):
                        if len(outputs.shape) == 4:  # 分割任务输出 [B, C, H, W]
                            features = F.adaptive_avg_pool2d(outputs, (1, 1)).view(outputs.size(0), -1)
                        elif len(outputs.shape) == 2:  # 分类任务输出 [B, num_classes]
                            features = outputs
                        else:
                            continue
                    elif isinstance(outputs, (list, tuple)):
                        features = outputs[0] if len(outputs) > 0 else None
                        if features is None:
                            continue
                        if len(features.shape) == 4:
                            features = F.adaptive_avg_pool2d(features, (1, 1)).view(features.size(0), -1)
                    else:
                        continue

                    all_features.append(features.cpu().numpy())

                    # 提取标签
                    batch_labels = self._extract_labels(targets, outputs)
                    all_labels.extend(batch_labels)

                    sample_count += len(images)

                except Exception as e:
                    print(f"Error in forward pass: {e}")
                    continue

        if all_features:
            return np.concatenate(all_features, axis=0), np.array(all_labels)
        else:
            return np.array([]), np.array([])

    def _extract_labels(self, targets, outputs):
        """提取标签信息"""
        batch_labels = []

        if targets is None:
            # 如果没有标签，尝试从输出推断
            if isinstance(outputs, torch.Tensor):
                if len(outputs.shape) == 4:  # 分割任务
                    for i in range(outputs.size(0)):
                        # 基于输出的最大值判断类别
                        max_val = torch.max(outputs[i]).item()
                        batch_labels.append(1 if max_val > 0.5 else 0)
                elif len(outputs.shape) == 2:  # 分类任务
                    pred_labels = torch.argmax(outputs, dim=1)
                    batch_labels.extend(pred_labels.cpu().numpy().tolist())
            return batch_labels

        if isinstance(targets, torch.Tensor):
            if len(targets.shape) == 1:  # 分类标签
                batch_labels = targets.cpu().numpy().tolist()
            elif len(targets.shape) >= 3:  # 分割掩码
                for i in range(targets.size(0)):
                    mask = targets[i]
                    has_lesion = torch.sum(mask > 0.5) > 100
                    batch_labels.append(1 if has_lesion else 0)
            else:
                batch_labels = [0] * targets.size(0)

        elif isinstance(targets, (list, tuple)):
            for target in targets:
                if isinstance(target, dict):
                    if 'class_label' in target:
                        batch_labels.append(int(target['class_label']))
                    elif 'mask' in target:
                        mask = target['mask']
                        if isinstance(mask, torch.Tensor):
                            has_lesion = torch.sum(mask > 0.5) > 100
                            batch_labels.append(1 if has_lesion else 0)
                        else:
                            batch_labels.append(0)
                    else:
                        batch_labels.append(0)
                elif isinstance(target, (int, torch.Tensor)):
                    batch_labels.append(int(target))
                else:
                    batch_labels.append(0)
        else:
            batch_labels = [0] * len(outputs) if hasattr(outputs, '__len__') else [0]

        return batch_labels

    def extract_features_from_folder(self, data_folder, image_extensions=('.jpg', '.png', '.jpeg', '.bmp', '.tiff')):
        """从文件夹中提取图像特征"""
        data_folder = Path(data_folder)
        if not data_folder.exists():
            print(f"Data folder does not exist: {data_folder}")
            return np.array([]), np.array([])

        # 图像变换
        transform = transforms.Compose([
            transforms.Resize((224, 224)),
            transforms.ToTensor(),
            transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])
        ])

        all_features = []
        all_labels = []
        all_filenames = []

        self.model.eval()
        with torch.no_grad():
            # 遍历所有图像文件
            for img_path in data_folder.rglob('*'):
                if img_path.suffix.lower() in image_extensions:
                    try:
                        # 加载和预处理图像
                        image = Image.open(img_path).convert('RGB')
                        image_tensor = transform(image).unsqueeze(0).to(self.device)

                        # 前向传播
                        outputs = self.model(image_tensor)

                        # 提取特征
                        if isinstance(outputs, torch.Tensor):
                            if len(outputs.shape) == 4:
                                features = F.adaptive_avg_pool2d(outputs, (1, 1)).view(1, -1)
                            else:
                                features = outputs
                        else:
                            features = outputs[0] if isinstance(outputs, (list, tuple)) else outputs

                        all_features.append(features.cpu().numpy())

                        # 从文件路径推断标签
                        label = self._infer_label_from_path(img_path)
                        all_labels.append(label)
                        all_filenames.append(img_path.name)

                    except Exception as e:
                        print(f"Error processing {img_path}: {e}")
                        continue

        if all_features:
            return np.concatenate(all_features, axis=0), np.array(all_labels), all_filenames
        else:
            return np.array([]), np.array([]), []

    def _infer_label_from_path(self, img_path):
        """从文件路径推断标签"""
        path_str = str(img_path).lower()

        # 常见的医学图像标签推断
        if any(keyword in path_str for keyword in ['normal', 'benign', 'healthy']):
            return 0
        elif any(keyword in path_str for keyword in ['malignant', 'cancer', 'tumor']):
            return 2
        elif any(keyword in path_str for keyword in ['abnormal', 'lesion', 'disease']):
            return 1
        else:
            # 尝试从父目录名推断
            parent_name = img_path.parent.name.lower()
            if any(keyword in parent_name for keyword in ['0', 'normal', 'benign']):
                return 0
            elif any(keyword in parent_name for keyword in ['1', 'abnormal', 'lesion']):
                return 1
            elif any(keyword in parent_name for keyword in ['2', 'malignant', 'cancer']):
                return 2
            else:
                return 0  # 默认标签

    def cleanup(self):
        """清理钩子"""
        for hook in self.hooks:
            hook.remove()


class TSNEVisualizer:
    """t-SNE可视化器"""

    def __init__(self, save_dir="./tsne_visualizations"):
        self.save_dir = Path(save_dir)
        self.save_dir.mkdir(parents=True, exist_ok=True)

        # 设置绘图样式
        plt.style.use('seaborn-v0_8-whitegrid' if 'seaborn-v0_8-whitegrid' in plt.style.available else 'default')
        sns.set_palette("husl")

    def create_tsne_plot(self, features, labels, title="t-SNE Visualization",
                         filename="tsne_plot.png", n_components=2, perplexity=30,
                         n_iter=1000, use_pca=True, pca_components=50):
        """创建t-SNE可视化图"""

        if len(features) == 0:
            print("No features to visualize")
            return None

        print(f"Creating t-SNE plot with {len(features)} samples...")
        print(f"Feature dimension: {features.shape[1]}")

        # 预处理：PCA降维
        if use_pca and features.shape[1] > pca_components:
            print(f"Applying PCA: {features.shape[1]} -> {pca_components}")
            pca = PCA(n_components=pca_components, random_state=42)
            features_processed = pca.fit_transform(features)
            print(f"PCA explained variance: {pca.explained_variance_ratio_.sum():.3f}")
        else:
            features_processed = features

        # 调整perplexity
        max_perplexity = (len(features) - 1) // 3
        perplexity = min(perplexity, max_perplexity, 50)
        print(f"Using perplexity: {perplexity}")

        # 应用t-SNE
        print("Applying t-SNE transformation...")
        tsne = TSNE(
            n_components=n_components,
            perplexity=perplexity,
            n_iter=n_iter,
            random_state=42,
            verbose=0
        )

        try:
            features_tsne = tsne.fit_transform(features_processed)
        except Exception as e:
            print(f"t-SNE failed: {e}")
            return None

        # 创建可视化
        plt.figure(figsize=(12, 10))

        # 获取唯一标签和对应颜色
        unique_labels = np.unique(labels)
        n_labels = len(unique_labels)

        if n_labels <= 10:
            colors = plt.cm.tab10(np.linspace(0, 1, n_labels))
        else:
            colors = plt.cm.tab20(np.linspace(0, 1, min(n_labels, 20)))

        # 定义标签名称映射
        label_names = self._get_label_names(unique_labels, title)

        # 绘制不同类别的点
        for i, label in enumerate(unique_labels):
            mask = labels == label
            color = colors[i % len(colors)]

            plt.scatter(
                features_tsne[mask, 0],
                features_tsne[mask, 1],
                c=[color],
                label=label_names.get(label, f'Class {label}'),
                alpha=0.7,
                s=30,
                edgecolors='white',
                linewidth=0.5
            )

        # 设置图表属性
        plt.title(title, fontsize=16, fontweight='bold', pad=20)
        plt.xlabel('t-SNE Component 1', fontsize=12)
        plt.ylabel('t-SNE Component 2', fontsize=12)

        # 设置图例
        if n_labels <= 10:
            plt.legend(bbox_to_anchor=(1.05, 1), loc='upper left')
        else:
            plt.legend(bbox_to_anchor=(1.05, 1), loc='upper left', ncol=2)

        plt.grid(True, alpha=0.3)
        plt.tight_layout()

        # 保存图像
        save_path = self.save_dir / filename
        plt.savefig(save_path, dpi=300, bbox_inches='tight', facecolor='white')
        print(f"t-SNE plot saved to: {save_path}")

        plt.show()
        plt.close()

        return features_tsne

    def _get_label_names(self, unique_labels, title):
        """根据数据集类型获取标签名称"""
        label_names = {}
        title_lower = title.lower()

        if 'busi' in title_lower or 'breast' in title_lower:
            mapping = {0: 'Normal', 1: 'Benign', 2: 'Malignant'}
        elif 'isic' in title_lower or 'skin' in title_lower:
            mapping = {0: 'Melanoma', 1: 'Seborrheic Keratosis', 2: 'Nevus'}
        elif 'aptos' in title_lower or 'retina' in title_lower:
            mapping = {0: 'No DR', 1: 'Mild', 2: 'Moderate', 3: 'Severe', 4: 'Proliferative'}
        elif 'kvasir' in title_lower:
            mapping = {0: 'No Polyp', 1: 'Polyp'}
        else:
            mapping = {label: f'Class {label}' for label in unique_labels}

        for label in unique_labels:
            label_names[label] = mapping.get(label, f'Class {label}')

        return label_names

    def create_multi_dataset_plot(self, features_dict, labels_dict,
                                  filename="multi_dataset_tsne.png"):
        """创建多数据集对比t-SNE图"""

        all_features = []
        all_labels = []
        dataset_labels = []

        # 收集所有数据集的特征
        for dataset_name, features in features_dict.items():
            if dataset_name in labels_dict and len(features) > 0:
                all_features.append(features)
                all_labels.extend(labels_dict[dataset_name])
                dataset_labels.extend([dataset_name] * len(features))

        if not all_features:
            print("No features found for multi-dataset visualization")
            return None

        # 合并所有特征
        all_features = np.concatenate(all_features, axis=0)
        all_labels = np.array(all_labels)
        dataset_labels = np.array(dataset_labels)

        print(f"Multi-dataset t-SNE: {len(all_features)} samples from {len(features_dict)} datasets")

        # PCA预处理
        if all_features.shape[1] > 50:
            pca = PCA(n_components=50, random_state=42)
            all_features = pca.fit_transform(all_features)

        # 调整perplexity
        perplexity = min(30, (len(all_features) - 1) // 3, 50)

        # t-SNE
        tsne = TSNE(n_components=2, perplexity=perplexity, n_iter=1000, random_state=42)
        features_tsne = tsne.fit_transform(all_features)

        # 创建图表
        plt.figure(figsize=(15, 12))

        # 按数据集着色
        unique_datasets = list(features_dict.keys())
        colors = plt.cm.tab10(np.linspace(0, 1, len(unique_datasets)))

        for i, dataset in enumerate(unique_datasets):
            mask = dataset_labels == dataset
            if np.any(mask):
                plt.scatter(
                    features_tsne[mask, 0], features_tsne[mask, 1],
                    c=[colors[i]], label=dataset,
                    alpha=0.6, s=25, edgecolors='white', linewidth=0.3
                )

        plt.title('Multi-Dataset Feature Distribution Comparison',
                  fontsize=16, fontweight='bold', pad=20)
        plt.xlabel('t-SNE Component 1', fontsize=12)
        plt.ylabel('t-SNE Component 2', fontsize=12)
        plt.legend(bbox_to_anchor=(1.05, 1), loc='upper left')
        plt.grid(True, alpha=0.3)
        plt.tight_layout()

        # 保存图像
        save_path = self.save_dir / filename
        plt.savefig(save_path, dpi=300, bbox_inches='tight', facecolor='white')
        print(f"Multi-dataset t-SNE saved to: {save_path}")

        plt.show()
        plt.close()

        return features_tsne


def load_model_from_checkpoint(model_path, device, model_class=None):
    """从检查点加载模型"""
    print(f"Loading model from: {model_path}")

    try:
        checkpoint = torch.load(model_path, map_location=device)

        if model_class is not None:
            # 如果提供了模型类，创建新实例
            model = model_class()
            if 'model_state_dict' in checkpoint:
                model.load_state_dict(checkpoint['model_state_dict'])
            elif 'state_dict' in checkpoint:
                model.load_state_dict(checkpoint['state_dict'])
            else:
                model.load_state_dict(checkpoint)
        else:
            # 尝试直接使用检查点中的模型
            if 'model' in checkpoint:
                model = checkpoint['model']
            elif hasattr(checkpoint, 'eval'):
                model = checkpoint
            else:
                print("Cannot determine model structure from checkpoint")
                return None

        model = model.to(device)
        model.eval()
        print("Model loaded successfully!")
        return model

    except Exception as e:
        print(f"Error loading model: {e}")
        return None


def main():
    """主函数"""
    parser = argparse.ArgumentParser(description="Create t-SNE visualizations for deep learning models")

    parser.add_argument("--model_path", type=str, required=True,
                        help="Path to model checkpoint (.pth file)")
    parser.add_argument("--data_path", type=str, required=True,
                        help="Path to data (folder or dataloader)")
    parser.add_argument("--output_dir", type=str, default="./tsne_visualizations",
                        help="Output directory for visualizations")
    parser.add_argument("--dataset_name", type=str, default="Custom Dataset",
                        help="Name of the dataset for plot titles")
    parser.add_argument("--max_samples", type=int, default=800,
                        help="Maximum number of samples to use")
    parser.add_argument("--perplexity", type=int, default=30,
                        help="Perplexity parameter for t-SNE")
    parser.add_argument("--use_pca", action='store_true', default=True,
                        help="Use PCA preprocessing")
    parser.add_argument("--pca_components", type=int, default=50,
                        help="Number of PCA components")

    args = parser.parse_args()

    # 设置设备
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    print(f"Using device: {device}")

    # 加载模型
    model = load_model_from_checkpoint(args.model_path, device)
    if model is None:
        print("Failed to load model. Exiting.")
        return

    # 创建特征提取器
    extractor = FeatureExtractor(model, device)

    # 创建可视化器
    visualizer = TSNEVisualizer(save_dir=args.output_dir)

    try:
        # 从文件夹提取特征
        print(f"Extracting features from: {args.data_path}")
        features, labels, filenames = extractor.extract_features_from_folder(
            args.data_path
        )

        if len(features) == 0:
            print("No features extracted. Please check your data path and model.")
            return

        # 限制样本数量
        if len(features) > args.max_samples:
            indices = np.random.choice(len(features), args.max_samples, replace=False)
            features = features[indices]
            labels = labels[indices]
            filenames = [filenames[i] for i in indices]

        print(f"Extracted {len(features)} features")
        print(f"Feature shape: {features.shape}")
        print(f"Label distribution: {np.bincount(labels)}")

        # 创建t-SNE可视化
        title = f"t-SNE Visualization - {args.dataset_name}"
        filename = f"tsne_{args.dataset_name.lower().replace(' ', '_')}.png"

        visualizer.create_tsne_plot(
            features=features,
            labels=labels,
            title=title,
            filename=filename,
            perplexity=args.perplexity,
            use_pca=args.use_pca,
            pca_components=args.pca_components
        )

        print("Visualization completed successfully!")

    except Exception as e:
        print(f"Error during visualization: {e}")
        import traceback
        traceback.print_exc()

    finally:
        # 清理资源
        extractor.cleanup()


# 便捷调用函数
def create_tsne_from_model(model_path, data_path, output_dir="./tsne_visualizations",
                           dataset_name="Custom Dataset", max_samples=800):
    """
    便捷函数：为已训练模型创建t-SNE可视化

    Args:
        model_path: 模型检查点路径
        data_path: 数据文件夹路径
        output_dir: 输出目录
        dataset_name: 数据集名称
        max_samples: 最大样本数量
    """
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

    # 加载模型
    model = load_model_from_checkpoint(model_path, device)
    if model is None:
        print("Failed to load model")
        return

    # 创建特征提取器和可视化器
    extractor = FeatureExtractor(model, device)
    visualizer = TSNEVisualizer(save_dir=output_dir)

    try:
        # 提取特征
        features, labels, _ = extractor.extract_features_from_folder(data_path)

        if len(features) == 0:
            print("No features extracted")
            return

        # 限制样本数量
        if len(features) > max_samples:
            indices = np.random.choice(len(features), max_samples, replace=False)
            features = features[indices]
            labels = labels[indices]

        # 创建可视化
        title = f"t-SNE Visualization - {dataset_name}"
        filename = f"tsne_{dataset_name.lower().replace(' ', '_')}.png"

        visualizer.create_tsne_plot(
            features=features,
            labels=labels,
            title=title,
            filename=filename
        )

        print(f"t-SNE visualization created for {dataset_name}")

    except Exception as e:
        print(f"Error: {e}")
    finally:
        extractor.cleanup()


if __name__ == "__main__":
    main()
