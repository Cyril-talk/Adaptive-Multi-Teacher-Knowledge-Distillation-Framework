import os
import json
import numpy as np
import pandas as pd
from PIL import Image
import torch
from torch.utils.data import Dataset, DataLoader
from torchvision import transforms
import cv2
from typing import Dict, List, Tuple, Optional, Union
import albumentations as A
from albumentations.pytorch import ToTensorV2

class UnifiedMedicalDataset(Dataset):
    """
    统一的医学图像数据集类，支持多任务学习
    """
    def __init__(self, 
                 data_configs: Dict,
                 transform=None,
                 mode='train',
                 target_size=(224, 224)):
        """
        Args:
            data_configs: 包含各数据集配置的字典
            transform: 数据增强变换
            mode: 'train', 'val', 'test'
            target_size: 统一的图像尺寸
        """
        self.data_configs = data_configs
        self.transform = transform
        self.mode = mode
        self.target_size = target_size
        
        # 整合所有数据集的样本
        self.samples = self._integrate_datasets()
        
    def _integrate_datasets(self) -> List[Dict]:
        """整合所有数据集的样本信息"""
        all_samples = []
        
        for dataset_name, config in self.data_configs.items():
            dataset_samples = self._load_dataset_samples(dataset_name, config)
            all_samples.extend(dataset_samples)
            
        return all_samples
    
    def _load_dataset_samples(self, dataset_name: str, config: Dict) -> List[Dict]:
        """加载单个数据集的样本"""
        samples = []
        
        if dataset_name == 'BUSI':
            samples = self._load_busi_samples(config)
        elif dataset_name == 'ISIC2017':
            samples = self._load_isic_samples(config)
        elif dataset_name == 'APTOS2019':
            samples = self._load_aptos_samples(config)
        elif dataset_name == "kvasir_seg":
            samples = self._load_kvasir_seg_samplles(config)
            
        return samples
    
    def _load_busi_samples(self, config: Dict) -> List[Dict]:
        """加载BUSI数据集 - 分割任务"""
        samples = []
        data_dir = config['data_dir']

        # 遍历BUSI数据集文件
        for split_dir in ['train', 'val', 'test']:
            split_path = os.path.join(data_dir, split_dir)
            if not os.path.exists(split_path):
                continue

            labels = config['labels']
            for label_index, label in enumerate(labels):
                file_dir = os.path.join(split_path, label)
                for _, file in enumerate(os.listdir(file_dir)):
                    if "_mask.png" in file:
                        mask_path = os.path.join(file_dir, file)
                        img_path = os.path.join(file_dir, file.replace("_mask", ""))
                        if os.path.exists(img_path):
                            samples.append({
                                'dataset': 'BUSI',
                                'task_type': 'segmentation',
                                'image_path': img_path,
                                'mask_path': mask_path,
                                'label': label_index,  
                                'bbox': None,   
                            })
        print("BUSI: ", len(samples))
        return samples
    
    def _load_isic_samples(self, config: Dict) -> List[Dict]:
        """加载ISIC2017数据集 - 识别任务"""
        samples = []
        data_dir = config['data_dir']
        
        # 遍历BUSI数据集文件
        for split_dir in ['Training', 'Validation', 'Test']:
            if "Training" in split_dir:
                split_dir = "ISIC-2017_Training_Data"
            elif "Validation" in split_dir:
                split_dir = "ISIC-2017_Validation_Data"
            else:
                split_dir = "ISIC-2017_Test_v2_Data"
            file_dir = os.path.join(data_dir, split_dir)
            if not os.path.exists(file_dir):
                continue
            
            for _, file in enumerate(os.listdir(file_dir)):
                if "_superpixels" in file or ".csv" in file:
                    continue
                
                img_path = os.path.join(file_dir, file)
                mask_path = os.path.join(file_dir.replace("_Data", "_Part1_GroundTruth"), file.replace(".jpg", "_segmentation.png"))
                annotation_path = os.path.join(file_dir.replace("_Data", "_Annotations"), file.replace(".jpg", "_annotation.json"))
                if not (os.path.exists(mask_path) and os.path.exists(annotation_path)):
                    continue 

                with open(annotation_path, 'r', encoding="utf-8") as f:
                        annotations = json.load(f)

                # 提取边界框和类别
                bboxes = []
                labels = []
                for ann in annotations:
                    bbox = ann['ann']  # [x, y, width, height]
                    category_id = ann['category_id']
                    bboxes.append(bbox)
                    labels.append(category_id)

                samples.append({
                    'dataset': 'ISIC2017',
                    'task_type': 'recognition', 
                    'image_path': img_path,
                    'mask_path': mask_path,
                    'label': labels,
                    'bbox': bboxes,
                })
        
        # 读取标签文件
        label_file = os.path.join(data_dir, f'{self.mode}_labels.csv')
        if os.path.exists(label_file):
            labels_df = pd.read_csv(label_file)
            
            for _, row in labels_df.iterrows():
                img_name = row['image_id']
                img_path = os.path.join(data_dir, 'images', f'{img_name}.jpg')
                
                if os.path.exists(img_path):
                    # ISIC2017通常是二分类或多分类
                    label = row['melanoma'] if 'melanoma' in row else row['label']
                    
                    samples.append({
                        'dataset': 'ISIC2017',
                        'task_type': 'recognition',
                        'image_path': img_path,
                        'mask_path': None,
                        'label': label,
                        'bbox': None,
                    })
        
        print("ISIC: ", len(samples))
        return samples
    
    def _load_aptos_samples(self, config: Dict) -> List[Dict]:
        """加载APTOS2019数据集 - 分类任务"""
        samples = []
        data_dir = config['data_dir']
        for split_dir in ['train', 'val', 'test']:
            split_path = os.path.join(data_dir, split_dir)
            if not os.path.exists(split_path):
                continue

            labels = config['labels']
            for label_index, label in enumerate(labels):
                file_dir = os.path.join(split_path, label)
                for _, file in enumerate(os.listdir(file_dir)):
                    if ".png" in file:
                        img_path = os.path.join(file_dir, file)
                        if os.path.exists(img_path):
                            samples.append({
                                'dataset': 'APTOS2019',
                                'task_type': 'classification',
                                'image_path': img_path,
                                'mask_path': None,
                                'label': label_index,  
                                'bbox': None,   
                            })
        
        print("apto: ", len(samples))
        return samples
    
    def _load_kvasir_seg_samplles(self, config: Dict) -> List[Dict]:
        # 加载Kvasir_seg数据集
        samples = []
        data_dir = config['data_dir']
        with open(os.path.join(data_dir, 'kavsir_bboxes.json'), 'r', encoding='UTF-8') as file:
            boxes_dict = json.loads(file.read())
        images_path = os.path.join(data_dir, 'images')
        masks_path = os.path.join(data_dir, 'masks')
        for _, file in enumerate(os.listdir(images_path)):
            
            img_path = os.path.join(images_path, file)
            mask_path = os.path.join(masks_path, file)
            if not ((os.path.exists(img_path)) and (os.path.exists(mask_path))):
                continue
            temp_dict = boxes_dict.get(file[:-4], {})
            if temp_dict:
                bbox = temp_dict['bbox']

            # 提取边界框和类别
            bboxes = []
            labels = []
            for b_info in bbox:
                bbox = [b_info['xmin'], b_info['ymin'], b_info['xmax'] - b_info['xmin'], b_info['ymax'] - b_info['ymin']]
                category_id = b_info['label']
                bboxes.append(bbox)
                labels.append(category_id)

            samples.append({
                'dataset': 'kvasir_seg',
                'task_type': 'segmentation', 
                'image_path': img_path,
                'mask_path': mask_path,
                'label': labels,
                'bbox': bboxes,
            })
        print("kvasir_seg: ", len(samples))
        return samples
    def __len__(self):
        return len(self.samples)
    
    def __getitem__(self, idx):
        sample = self.samples[idx]
        
        # 加载图像
        image = Image.open(sample['image_path']).convert('RGB')
        image = np.array(image)
        
        # 根据任务类型准备标签
        targets = self._prepare_targets(sample)
        
        # 应用数据增强
        if self.transform:
            if sample['task_type'] == 'segmentation' and sample['mask_path']:
                mask = cv2.imread(sample['mask_path'], cv2.IMREAD_GRAYSCALE)
                transformed = self.transform(image=image, mask=mask)
                image = transformed['image']
                targets['mask'] = transformed['mask']
            else:
                transformed = self.transform(image=image)
                image = transformed['image']
        
        # 统一图像尺寸
        if not isinstance(image, torch.Tensor):
            image = torch.from_numpy(image).permute(2, 0, 1).float() / 255.0
        
        return {
            'image': image,
            'targets': targets,
            'dataset': sample['dataset'],
            'task_type': sample['task_type']
        }
    
    def _prepare_targets(self, sample: Dict) -> Dict:
        """准备不同任务的目标标签"""
        targets = {
            'task_type': sample['task_type'],
            'dataset': sample['dataset']
        }
        
        if sample['task_type'] == 'segmentation':
            if sample['mask_path']:
                mask = cv2.imread(sample['mask_path'], cv2.IMREAD_GRAYSCALE)
                mask = cv2.resize(mask, self.target_size)
                targets['mask'] = torch.from_numpy(mask).long()
            else:
                targets['mask'] = torch.zeros(self.target_size, dtype=torch.long)
                
        elif sample['task_type'] == 'classification':

            targets['class_label'] = torch.tensor(sample['label'], dtype=torch.long)
            
        elif sample['task_type'] == 'recognition':
            # 处理检测标签
            if sample['bbox'] and sample['label']:
                targets['boxes'] = torch.tensor(sample['bbox'], dtype=torch.float32)
                targets['labels'] = torch.tensor(sample['label'], dtype=torch.long)
            else:
                targets['boxes'] = torch.empty((0, 4), dtype=torch.float32)
                targets['labels'] = torch.empty((0,), dtype=torch.long)
        
        return targets


class DataIntegrationManager:
    """数据整合管理器"""
    
    def __init__(self, config_file: str):
        with open(config_file, 'r') as f:
            self.config = json.load(f)
    
    def create_transforms(self) -> Dict:
        """创建数据增强变换"""
        train_transform = A.Compose([
            A.Resize(224, 224),
            A.HorizontalFlip(p=0.5),
            A.RandomRotate90(p=0.5),
            A.ColorJitter(brightness=0.2, contrast=0.2, saturation=0.2, hue=0.1, p=0.5),
            A.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225]),
            ToTensorV2(),
        ])
        
        val_transform = A.Compose([
            A.Resize(224, 224),
            A.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225]),
            ToTensorV2(),
        ])
        
        return {'train': train_transform, 'val': val_transform, 'test': val_transform}
    
    def create_dataloaders(self, batch_size: int = 16) -> Dict:
        """创建数据加载器"""
        transforms = self.create_transforms()
        dataloaders = {}
        
        for mode in ['train', 'val', 'test']:
            dataset = UnifiedMedicalDataset(
                data_configs=self.config['datasets'],
                transform=transforms[mode],
                mode=mode
            )
            
            dataloaders[mode] = DataLoader(
                dataset,
                batch_size=batch_size,
                shuffle=(mode == 'train'),
                num_workers=4,
                collate_fn=self.custom_collate_fn
            )
        
        return dataloaders
    
    def custom_collate_fn(self, batch):
        """自定义批次整理函数，处理不同任务的数据"""
        images = []
        targets_by_task = {'segmentation': [], 'classification': [], 'recognition': []}
        datasets = []
        task_types = []
        
        for item in batch:
            images.append(item['image'])
            datasets.append(item['dataset'])
            task_types.append(item['task_type'])
            
            task_type = item['task_type']
            targets_by_task[task_type].append(item['targets'])
        
        return {
            'images': torch.stack(images),
            'targets_by_task': targets_by_task,
            'datasets': datasets,
            'task_types': task_types
        }
    
    def analyze_dataset_statistics(self):
        """分析数据集统计信息"""
        stats = {}
        
        for mode in ['train', 'val', 'test']:
            dataset = UnifiedMedicalDataset(
                data_configs=self.config['datasets'],
                transform=None,
                mode=mode
            )
            
            task_counts = {}
            dataset_counts = {}
            
            for sample in dataset.samples:
                task_type = sample['task_type']
                dataset_name = sample['dataset']
                
                task_counts[task_type] = task_counts.get(task_type, 0) + 1
                dataset_counts[dataset_name] = dataset_counts.get(dataset_name, 0) + 1
            
            stats[mode] = {
                'total_samples': len(dataset.samples),
                'task_distribution': task_counts,
                'dataset_distribution': dataset_counts
            }
        
        return stats


# 示例配置文件内容
example_config = {
    "datasets": {
        "BUSI": {
            "data_dir": "./datasets/BUSI",
            "task_type": "segmentation",
            "num_classes": 3,
            "labels": ['benign', 'malignant', 'normal'],
        },
        "ISIC2017": {
            "data_dir": "./datasets/ISIC2017",
            "task_type": "recognition", 
            "num_classes": 3,
            "labels":["melanoma", "seborrheic_keratosis", "nevus/benign pigmented lesion"]
        },
        "APTOS2019": {
            "data_dir": "./datasets/APTOS2019",
            "task_type": "classification",
            "num_classes": 5,
            "labels":['anodr', 'bmilddr', 'cmoderatedr', 'dseveredr', 'eproliferativedr'],
        },
        "kvasir_seg":{
            "data_dir": "./datasets/Kvasir-SEG",
            "task_type": "segmentation",
            "num_classes": 1,
            "labels": ['polyp']
        }
    },
    "training": {
        "batch_size": 16,
        "num_epochs": 100,
        "learning_rate": 0.001
    },

}

# 使用示例
if __name__ == "__main__":
    # 保存配置文件
    with open('data_config.json', 'w') as f:
        json.dump(example_config, f, indent=2)
    
    # 创建数据管理器
    manager = DataIntegrationManager('data_config.json')
    
    # 创建数据加载器
    dataloaders = manager.create_dataloaders(batch_size=16)
    
    # 分析数据集统计
    stats = manager.analyze_dataset_statistics()
    print("Dataset Statistics:")
    for mode, mode_stats in stats.items():
        print(f"\n{mode.upper()} Set:")
        print(f"  Total samples: {mode_stats['total_samples']}")
        print(f"  Task distribution: {mode_stats['task_distribution']}")
        print(f"  Dataset distribution: {mode_stats['dataset_distribution']}")
    
    # 训练集数据加载
    train_loader = dataloaders['train']
    for batch in train_loader:
        print(batch)
        print("\nBatch structure:")
        print(f"  Images shape: {batch['images'].shape}")
        print(f"  Task types: {set(batch['task_types'])}")
        print(f"  Datasets: {set(batch['datasets'])}")
        break