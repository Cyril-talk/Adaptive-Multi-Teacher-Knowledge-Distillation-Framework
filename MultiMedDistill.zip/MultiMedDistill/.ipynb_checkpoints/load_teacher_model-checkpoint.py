import sys 
sys.path.append('./BiomedParse/')
sys.path.append('./MedSAM/')
sys.path.append('./RETFound_MAE/')


def load_biomedprase_model():
    from BiomedParse.modeling.BaseModel import BaseModel
    from BiomedParse.modeling import build_model
    from BiomedParse.utilities.distributed import init_distributed
    from BiomedParse.utilities.arguments import load_opt_from_config_files
    from BiomedParse.utilities.constants import BIOMED_CLASSES

    opt = load_opt_from_config_files(["configs/biomedparse_inference.yaml"])
    opt = init_distributed(opt)

    # Load model from pretrained weights
    pretrained_pth = '/root/autodl-tmp/teacher_model/biomedparse_v1.pt'

    model = BaseModel(opt, build_model(opt)).from_pretrained(pretrained_pth).eval().cuda()

    return model

def load_MedSAM_model():
    from MedSAM.segment_anything import sam_model_registry
    MedSAM_CKPT_PATH = "/root/autodl-tmp/teacher_model/medsam_vit_b.pth"
    device = "cuda:0"
    medsam_model = sam_model_registry['vit_b'](checkpoint=MedSAM_CKPT_PATH)
    medsam_model = medsam_model.to(device)
    medsam_model.eval().cuda()
    return medsam_model

def load_USFM_model():
    import torch
    from omegaconf import OmegaConf
    from usfm.models.beitSegLit import BeitSegLit
    cfg_file = "/root/projects/upernet_beit_base.yaml"
    net_cfg = OmegaConf.load(cfg_file)['net']
    teacher = BeitSegLit(net=net_cfg,
                            optimizer=None,
                            scheduler=None,
                            metric_keys=[])
    model_path = '/root/autodl-tmp/teacher_model/USFM_latest.pth'
    print(f"==> 加载权重: {model_path}")
    state = torch.load(model_path, map_location='cpu')
    teacher.load_state_dict(state['model'] if isinstance(state, dict) and 'model' in state else state,
                            strict=False)
    return teacher

def load_RETFound_MAE_model():
    import torch
    import RETFound_MAE.models_mae as models_mae
    arch = 'mae_vit_large_patch16'
    model = getattr(models_mae, arch)()
    chkpt_dir = '/root/autodl-tmp/teacher_model/RETFound_oct_weights.pth'
    # load model
    checkpoint = torch.load(chkpt_dir, weights_only=False)
    msg = model.load_state_dict(checkpoint['model'], strict=False)
    return model

if __name__ == "__main__":
    load_USFM_model() # mim install mmcv  
    #  pip install mmcv==2.2.0 -f https://download.openmmlab.com/mmcv/dist/cu124/torch2.5/index.html 
    # load_RETFound_MAE_model()