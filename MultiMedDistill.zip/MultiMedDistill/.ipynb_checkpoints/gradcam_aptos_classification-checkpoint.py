import torch
import torch.nn as nn
import torch.nn.functional as F
import torchvision.transforms as transforms
from torch.utils.data import DataLoader, Dataset
import numpy as np
import cv2
import matplotlib.pyplot as plt
from PIL import Image
import argparse
from pathlib import Path
from collections import OrderedDict
import random
import os

def set_seed(seed):
    """Set global random seed for reproducibility"""
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False
    print(f"Random seed set to: {seed}")

class APTOS2019Dataset(Dataset):
    """APTOS2019 Diabetic Retinopathy Classification Dataset"""
    def __init__(self, root_dir, transform=None):
        self.root_dir = Path(root_dir)
        self.transform = transform
        self.images = []
        self.labels = []
        
        # APTOS2019 class mappings
        self.class_folders = [
            'anodr',           # 0: No DR
            'bmilddr',         # 1: Mild DR  
            'cmoderatedr',     # 2: Moderate DR
            'dseveredr',       # 3: Severe DR
            'eproliferativedr' # 4: Proliferative DR
        ]
        
        self.class_names = [
            'No DR',
            'Mild DR',
            'Moderate DR',
            'Severe DR',
            'Proliferative DR'
        ]
        
        print(f"Loading APTOS2019 dataset from: {root_dir}")
        self._load_from_named_directories()
    
    def _load_from_named_directories(self):
        """Load images from named class directories"""
        print("Loading from named class directories...")
        
        valid_extensions = {'.jpg', '.jpeg', '.png', '.bmp', '.tif', '.tiff'}
        
        for class_idx, folder_name in enumerate(self.class_folders):
            class_dir = self.root_dir / folder_name
            
            if not class_dir.exists():
                print(f"Warning: Class directory '{folder_name}' not found, skipping...")
                continue
                
            class_images = []
            for ext in valid_extensions:
                class_images.extend(list(class_dir.glob(f'*{ext}')))
                class_images.extend(list(class_dir.glob(f'*{ext.upper()}')))
            
            for img_path in class_images:
                self.images.append(str(img_path))
                self.labels.append(class_idx)
                
            print(f"Class {class_idx} ({folder_name} -> {self.class_names[class_idx]}): {len(class_images)} images")
        
        print(f"Total loaded: {len(self.images)} images from {len(set(self.labels))} classes")
    
    def __len__(self):
        return len(self.images)
    
    def __getitem__(self, idx):
        img_path = self.images[idx]
        label = self.labels[idx]
        
        try:
            image = Image.open(img_path).convert('RGB')
            original_image = np.array(image)  # Save original image for visualization
            
            if self.transform:
                image = self.transform(image)
            return image, label, original_image, img_path
        except Exception as e:
            print(f"Error loading image {img_path}: {e}")
            dummy = Image.new('RGB', (224, 224), (0, 0, 0))
            dummy_array = np.array(dummy)
            if self.transform:
                dummy = self.transform(dummy)
            return dummy, label, dummy_array, img_path

class ClassificationModel(nn.Module):
    """Complete classification model for GradCAM"""
    def __init__(self, state_dict, model_type='efficientnet', num_classes=5):
        super().__init__()
        
        self.model_type = model_type
        
        if model_type == 'efficientnet':
            from torchvision.models import efficientnet_b0
            self.backbone = efficientnet_b0(weights=None)
            self.backbone.classifier = nn.Linear(self.backbone.classifier[1].in_features, num_classes)
        elif model_type == 'resnet':
            from torchvision.models import resnet50
            self.backbone = resnet50(weights=None)
            self.backbone.fc = nn.Linear(self.backbone.fc.in_features, num_classes)
        else:
            raise ValueError(f"Unsupported model type: {model_type}")
        
        # Handle multi-task model weights
        if isinstance(state_dict, dict) and any(key.startswith('backbone.') for key in state_dict.keys()):
            # Multi-task model format
            backbone_state = OrderedDict()
            classifier_state = OrderedDict()
            
            for key, value in state_dict.items():
                if key.startswith('backbone.'):
                    new_key = key[9:]  # Remove 'backbone.' prefix
                    backbone_state[new_key] = value
                elif key.startswith('classifier.') or key.startswith('fc.'):
                    classifier_state[key] = value
            
            # Merge weights
            full_state = {**backbone_state, **classifier_state}
        else:
            full_state = state_dict
        
        # Load weights
        try:
            self.backbone.load_state_dict(full_state, strict=False)
            print("✓ Complete model weights loaded successfully!")
        except Exception as e:
            print(f"Warning: {e}")
            model_dict = self.backbone.state_dict()
            filtered_dict = {k: v for k, v in full_state.items() 
                           if k in model_dict and v.shape == model_dict[k].shape}
            model_dict.update(filtered_dict)
            self.backbone.load_state_dict(model_dict)
            print(f"✓ Loaded {len(filtered_dict)}/{len(full_state)} compatible weights")
    
    def forward(self, x):
        return self.backbone(x)

class GradCAM:
    """GradCAM implementation"""
    def __init__(self, model, target_layer):
        self.model = model
        self.target_layer = target_layer
        self.gradients = None
        self.activations = None
        
        # Register hooks
        self.target_layer.register_forward_hook(self.save_activation)
        self.target_layer.register_backward_hook(self.save_gradient)
    
    def save_activation(self, module, input, output):
        self.activations = output.detach()
    
    def save_gradient(self, module, grad_input, grad_output):
        self.gradients = grad_output[0]
    
    def generate_cam(self, input_tensor, target_class=None):
        """Generate GradCAM heatmap"""
        # Ensure input requires gradients
        input_tensor.requires_grad_(True)
        
        # Forward pass
        output = self.model(input_tensor)
        
        if target_class is None:
            target_class = output.argmax(dim=1).item()
        elif isinstance(target_class, torch.Tensor):
            target_class = target_class.item()
        
        # Zero gradients
        self.model.zero_grad()
        
        # Backward pass to specified class
        one_hot = torch.zeros_like(output)
        one_hot[0][target_class] = 1.0
        output.backward(gradient=one_hot, retain_graph=True)
        
        # Check if gradients are captured
        if self.gradients is None:
            print("Warning: No gradients captured!")
            return np.zeros((224, 224)), output.detach().cpu().numpy()
        
        # Calculate weights
        gradients = self.gradients[0]  # [C, H, W]
        activations = self.activations[0]  # [C, H, W]
        
        weights = torch.mean(gradients, dim=(1, 2))  # [C]
        
        # Calculate weighted feature map
        cam = torch.zeros(activations.shape[1:], device=activations.device)
        for i, w in enumerate(weights):
            cam += w * activations[i]
        
        # ReLU activation
        cam = F.relu(cam)
        
        # Normalize
        cam = cam - cam.min()
        if cam.max() > 0:
            cam = cam / cam.max()
        
        return cam.detach().cpu().numpy(), output.detach().cpu().numpy()

def get_target_layer(model, model_type='efficientnet'):
    """Get target layer for GradCAM"""
    if model_type == 'efficientnet':
        # Last convolutional layer of EfficientNet
        return model.backbone.features[-1]
    elif model_type == 'resnet':
        # Last convolutional layer of ResNet
        return model.backbone.layer4[-1].conv2
    else:
        raise ValueError(f"Unsupported model type: {model_type}")

def apply_gradcam_to_image(original_image, cam, alpha=0.4):
    """Apply GradCAM heatmap to original image"""
    # Resize CAM to original image size
    h, w = original_image.shape[:2]
    cam_resized = cv2.resize(cam, (w, h))
    
    # Create heatmap
    heatmap = cv2.applyColorMap(np.uint8(255 * cam_resized), cv2.COLORMAP_JET)
    heatmap = cv2.cvtColor(heatmap, cv2.COLOR_BGR2RGB)
    
    # Superimpose on original image
    superimposed = heatmap * alpha + original_image * (1 - alpha)
    superimposed = np.clip(superimposed, 0, 255).astype(np.uint8)
    
    return superimposed, heatmap

def generate_gradcam_visualization(model, dataset, device, output_dir, 
                                 model_type='efficientnet', max_samples_per_class=None):
    """Generate GradCAM visualization"""
    
    # Get target layer
    target_layer = get_target_layer(model, model_type)
    gradcam = GradCAM(model, target_layer)
    
    # Set model to train mode to enable gradient computation
    model.train()
    
    # Class names
    class_names = [
        'No DR',
        'Mild DR',
        'Moderate DR',
        'Severe DR',
        'Proliferative DR'
    ]
    
    # Organize samples by class
    class_samples = {i: [] for i in range(5)}
    
    # Collect samples for each class
    for i, (image, label, original, img_path) in enumerate(dataset):
        class_samples[label].append((image, label, original, img_path))
    
    # Limit samples per class if specified
    if max_samples_per_class:
        for class_idx in class_samples:
            if len(class_samples[class_idx]) > max_samples_per_class:
                class_samples[class_idx] = random.sample(class_samples[class_idx], max_samples_per_class)
    
    all_visualizations = []
    
    for class_idx in range(5):
        if not class_samples[class_idx]:
            continue
            
        print(f"Generating GradCAM for class {class_idx}: {class_names[class_idx]} ({len(class_samples[class_idx])} samples)")
        
        for sample_idx, (image, true_label, original, img_path) in enumerate(class_samples[class_idx]):
            # Prepare input
            input_tensor = image.unsqueeze(0).to(device)
            
            try:
                # Generate GradCAM
                cam, output = gradcam.generate_cam(input_tensor)
                predicted_class = np.argmax(output[0])
                confidence = F.softmax(torch.tensor(output[0]), dim=0)[predicted_class].item()
                
                # Apply GradCAM to original image
                superimposed, heatmap = apply_gradcam_to_image(original, cam)
                
                # Create visualization
                fig, axes = plt.subplots(1, 3, figsize=(15, 5))
                
                # Original image
                axes[0].imshow(original)
                axes[0].set_title(f'Original Image\nTrue: {class_names[true_label]}', fontsize=12)
                axes[0].axis('off')
                
                # Heatmap
                axes[1].imshow(heatmap)
                axes[1].set_title(f'GradCAM Heatmap\nPred: {class_names[predicted_class]} ({confidence:.3f})', fontsize=12)
                axes[1].axis('off')
                
                # Superimposed image
                axes[2].imshow(superimposed)
                axes[2].set_title('Superimposed', fontsize=12)
                axes[2].axis('off')
                
                # Save individual visualization
                img_name = Path(img_path).stem
                save_path = output_dir / f"gradcam_class_{class_idx}_{class_names[class_idx].replace(' ', '_')}_{sample_idx}_{img_name}.png"
                plt.tight_layout()
                plt.savefig(save_path, dpi=150, bbox_inches='tight')
                plt.close()
                
                all_visualizations.append({
                    'class_idx': class_idx,
                    'class_name': class_names[class_idx],
                    'true_label': true_label,
                    'predicted_class': predicted_class,
                    'confidence': confidence,
                    'original': original,
                    'heatmap': heatmap,
                    'superimposed': superimposed,
                    'img_path': img_path
                })
                
                if (sample_idx + 1) % 10 == 0:
                    print(f"  Generated {sample_idx + 1}/{len(class_samples[class_idx])} visualizations for {class_names[class_idx]}")
                
            except Exception as e:
                print(f"Error generating GradCAM for image {img_path}: {e}")
                continue
    
    # Create summary visualization
    if all_visualizations:
        create_summary_visualization(all_visualizations, output_dir)
    
    return all_visualizations

def create_summary_visualization(visualizations, output_dir):
    """Create summary visualization"""
    class_names = [
        'No DR', 'Mild DR', 'Moderate DR', 'Severe DR', 'Proliferative DR'
    ]
    
    # Select best example for each class
    class_examples = {}
    for viz in visualizations:
        class_idx = viz['class_idx']
        if class_idx not in class_examples or viz['confidence'] > class_examples[class_idx]['confidence']:
            class_examples[class_idx] = viz
    
    # Create grid visualization
    n_classes = len(class_examples)
    fig, axes = plt.subplots(n_classes, 3, figsize=(15, 4*n_classes))
    
    if n_classes == 1:
        axes = axes.reshape(1, -1)
    
    for i, (class_idx, viz) in enumerate(class_examples.items()):
        # Original image
        axes[i, 0].imshow(viz['original'])
        axes[i, 0].set_title(f'{viz["class_name"]}\n(Original)', fontsize=10)
        axes[i, 0].axis('off')
        
        # Heatmap
        axes[i, 1].imshow(viz['heatmap'])
        axes[i, 1].set_title(f'GradCAM Heatmap\nConf: {viz["confidence"]:.3f}', fontsize=10)
        axes[i, 1].axis('off')
        
        # Superimposed image
        axes[i, 2].imshow(viz['superimposed'])
        axes[i, 2].set_title('Superimposed', fontsize=10)
        axes[i, 2].axis('off')
    
    plt.suptitle('APTOS2019 GradCAM Visualization Summary\nDiabetic Retinopathy Classification', 
                fontsize=16, fontweight='bold')
    plt.tight_layout()
    
    summary_path = output_dir / "gradcam_summary_aptos2019.png"
    plt.savefig(summary_path, dpi=200, bbox_inches='tight')
    plt.close()
    
    print(f"✓ Summary visualization saved to: {summary_path}")

def load_classification_model(model_path, model_type='efficientnet', num_classes=5):
    """Load complete classification model"""
    print(f"Loading complete model from: {model_path}")
    
    try:
        checkpoint = torch.load(model_path, map_location='cpu', weights_only=False)
        
        if isinstance(checkpoint, dict):
            if 'model_state_dict' in checkpoint:
                state_dict = checkpoint['model_state_dict']
            elif 'state_dict' in checkpoint:
                state_dict = checkpoint['state_dict']
            else:
                state_dict = checkpoint
        else:
            state_dict = checkpoint
        
        model = ClassificationModel(state_dict, model_type, num_classes)
        return model
        
    except Exception as e:
        print(f"Error loading model: {e}")
        return None

def main():
    parser = argparse.ArgumentParser(description='Generate GradCAM visualization for APTOS2019 classification task')
    parser.add_argument('--model_path', required=True, help='Path to the trained classification model')
    parser.add_argument('--data_path', required=True, help='Path to the APTOS2019 data')
    parser.add_argument('--output_dir', default='./gradcam_results', help='Output directory')
    parser.add_argument('--max_samples_per_class', type=int, default=None, help='Maximum samples per class to visualize (None for all)')
    parser.add_argument('--random_seed', type=int, default=42, help='Random seed for reproducibility')
    parser.add_argument('--model_type', default='efficientnet', choices=['efficientnet', 'resnet'], 
                       help='Type of backbone model')
    parser.add_argument('--num_classes', type=int, default=5, help='Number of classes')
    
    args = parser.parse_args()
    
    # Set random seed
    set_seed(args.random_seed)
    
    # Create output directory
    output_dir = Path(args.output_dir)
    output_dir.mkdir(exist_ok=True)
    
    # Set device
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    print(f"Using device: {device}")
    
    # Load model
    model = load_classification_model(args.model_path, args.model_type, args.num_classes)
    if model is None:
        print("Failed to load model. Please check the model path.")
        return
    
    model = model.to(device)
    
    # Data transforms
    transform = transforms.Compose([
        transforms.Resize((224, 224)),
        transforms.ToTensor(),
        transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])
    ])
    
    # Load data
    print(f"Loading APTOS2019 data from: {args.data_path}")
    dataset = APTOS2019Dataset(args.data_path, transform=transform)
    
    if len(dataset) == 0:
        print("No images loaded! Please check your data path and structure.")
        return
    
    # Generate GradCAM visualization
    print("Generating GradCAM visualizations...")
    visualizations = generate_gradcam_visualization(
        model, dataset, device, output_dir, 
        args.model_type, args.max_samples_per_class
    )
    
    # Print statistics
    print("\n" + "="*70)
    print("APTOS2019 GradCAM Visualization Statistics")
    print("="*70)
    
    if visualizations:
        class_counts = {}
        correct_predictions = 0
        total_predictions = 0
        
        for viz in visualizations:
            class_idx = viz['class_idx']
            if class_idx not in class_counts:
                class_counts[class_idx] = 0
            class_counts[class_idx] += 1
            
            if viz['true_label'] == viz['predicted_class']:
                correct_predictions += 1
            total_predictions += 1
        
        class_names = [
            'No DR',
            'Mild DR',
            'Moderate DR',
            'Severe DR',
            'Proliferative DR'
        ]
        
        for class_idx in sorted(class_counts.keys()):
            count = class_counts[class_idx]
            print(f"{class_names[class_idx]}: {count} visualizations")
        
        accuracy = correct_predictions / total_predictions * 100 if total_predictions > 0 else 0
        print(f"\nAccuracy on visualized samples: {accuracy:.1f}% ({correct_predictions}/{total_predictions})")
        print(f"Total visualizations generated: {len(visualizations)}")
        print(f"Output directory: {output_dir}")
        
        print("="*70)
        print("✓ APTOS2019 GradCAM visualization completed successfully!")
    else:
        print("No visualizations were generated. Please check your model and data.")

if __name__ == "__main__":
    main()
