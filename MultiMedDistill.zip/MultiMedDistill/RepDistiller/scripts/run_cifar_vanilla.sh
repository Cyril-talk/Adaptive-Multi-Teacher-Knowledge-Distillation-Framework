# sample scripts for training vanilla teacher models

python train_teacher.py --model wrn_40_2

python train_teacher.py --model resnet56

python train_teacher.py --model resnet110

python train_teacher.py --model resnet32x4

python train_teacher.py --model vgg13

python train_teacher.py --model ResNet50
